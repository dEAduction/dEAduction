Dans ce dossier, des feuilles d'exercices très progressives créées pour un utilisateur débutant de Deaduction et en première année d'université.
